#!/usr/bin/env python3
# coding=utf-8

import random


def random_array(n, m, max_value=21):
    array = []
    for i in range(0, n):
        sub_array = []
        for j in range(m):
            number = random.randrange(-20, max_value, 1)
            sub_array.append(number)
        array.append(sub_array)
    return array


def print_array(array):
    print()
    for i in array:
        for j in i:
            print("%5d\t" % j, end='')
        print()


def counting(array):
    print()
    max2s = array[1][0]
    maxj = 0
    for j in range(len(array[1])):
        if max2s < array[1][j]:
            max2s = array[1][j]
            maxj = j
    print("Максимум второй строки: %d" % max2s)
    print("Первый элемент третьей строки: %d" % array[2][0])
    print()
    return max2s, maxj


def main():
    array = random_array(4, 5)
    print("Условие задания:\n"
          "Найти максимальный элемент второй строки.\n"
          "Если он больше первого элемента третьей строки,\n"
          "то поменять элементы местами")

    print_array(array)
    max2s, maxj = counting(array)
    while True:
        print("1. Заполнить массив случайными числами;")
        print("2. Выполнить задание;")
        print("3. Выход.")
        key = input('Введите команду (1, 2 или 3): ')
        if key == '1':
            array = random_array(4, 5)
            print_array(array)
            max2s, maxj = counting(array)
        elif key == '2':
            if max2s <= array[2][0]:
                print("Максимальный элемент второй строки (%d) не больше первого элемента третьей строки %d" % (max2s, array[2][0]))
                print("Задание не будет выполнено.")
            else:
                print("Максимальный элемент второй строки (%d) больше первого элемента третьей строки %d" % (max2s, array[2][0]))
                array[1][maxj] = array[2][0]
                array[2][0] = max2s
                print("Элементы поменялись местами")
                print_array(array)
                break
        elif key == '3':
            exit(0)


if __name__ == '__main__':
    main()
